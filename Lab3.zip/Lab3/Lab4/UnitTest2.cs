﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Lab4
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
