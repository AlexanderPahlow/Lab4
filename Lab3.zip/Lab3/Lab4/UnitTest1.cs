﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab3;
namespace Lab4
{
    /// <summary>
    /// this tests lab3
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        public IController controller;

        public UnitTest1()
        {
            Database data = new Database(); //create a database
            controller = new Controller(data); //create controller
            controller.CreateFlight("LAXX", "LAXE", "ADC127", 100);  //needs to be done here, doesn't work when called in deletion test for some reason
            controller.CreateFlight("LAXX", "LAXE", "AEC134", 100);  //for update test
        }


        /// <summary>
        /// This tries to create a flight with an invalid origin
        /// should return a OriginNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidOriginCreationTest()
        {
            Assert.AreEqual(FlightError.OriginNotValid, controller.CreateFlight("LAX1", "LAXE", "ABC124", 100));
        }

        /// <summary>
        /// This tests a valid creation
        /// </summary>
        [TestMethod]
        public void ValidCreationTest()
        {
            controller.DeleteFlight("ACC124"); //deletes the flight first just in case the database is not empty
            Assert.AreEqual(FlightError.None, controller.CreateFlight("LAXX", "LAXE", "ACC124", 100));
        }



        /// <summary>
        /// This tries to create a flight with an invalid destination
        /// should return a DestinationNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidDestinationCreationTest()
        {
            Assert.AreEqual(FlightError.DestinationNotValid, controller.CreateFlight("LAXE", "LAX1", "ABC125", 100));
        }




        /// <summary>
        /// This tries to create a flight with an invalid number of passengers
        /// should return a NumPaxNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidNumPaxCreationTest()
        {
            Assert.AreEqual(FlightError.NumPaxNotValid, controller.CreateFlight("LAXE", "LAXX", "ABC126", -1));
        }


        /// <summary>
        /// This tries to create a flight with an invalid FlightId
        /// should return a FlightError.FlightIdNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidFlightIdCreationTest()
        {
            Assert.AreEqual(FlightError.FlightIdNotValid, controller.CreateFlight("LAXE", "LAXX", "ABC12", 1000));
        }





        /// <summary>
        /// This tests a valid deletion 
        /// </summary>
        [TestMethod]
        public void ValidDeletionTest()
        {
            Assert.AreEqual(FlightError.None, controller.DeleteFlight("ADC127")); //this loves to fail if the flight is not already in the database even though we are creating it before hand
        }



        /// <summary>
        /// This tries to delete a flight with an invalid FlightId
        /// should return a FlightError.FlightIdNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidFlightIdDeletionTest()
        {
            Assert.AreEqual(FlightError.FlightIdNotValid, controller.DeleteFlight("ADC17"));
        }

        /// <summary>
        /// This tries to delete a flight that is not in the database
        /// should return a FlightError.FlightNotFound error
        /// </summary>
        [TestMethod]
        public void FlightDoesNotExistDeletionTest()
        {
            Assert.AreEqual(FlightError.FlightNotFound, controller.DeleteFlight("ADC177"));
        }


        /// <summary>
        /// This tests a valid update to a flight 
        /// </summary>
        [TestMethod]
        public void ValidUpdateTest()
        {
            Assert.AreEqual(FlightError.None, controller.UpdateFlight("LAEX", "FlOR", "AEC134", 1000)); 
        }



        /// <summary>
        /// This tries to update a flight with an invalid number of passengers
        /// should return a NumPaxNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidNumPaxUpdateTest()
        {
            Assert.AreEqual(FlightError.NumPaxNotValid, controller.UpdateFlight("XDLM", "FLOR", "AEC134", -10000)); //needs an existing flight Id to update
        }


        /// <summary>
        /// This tries to update a flight that is not in the database
        /// should return a FlightError.FlightNotFound error
        /// </summary>
        [TestMethod]
        public void FlightDoesNotExistUpdateTest()
        {
            Assert.AreEqual(FlightError.FlightNotFound, controller.UpdateFlight("XDLM", "FLOR", "AAC137", 8));
        }




        /// <summary>
        /// This tries to update a flight with an invalid destination
        /// should return a DestinationNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidDestinationUpdateTest()
        {
            Assert.AreEqual(FlightError.DestinationNotValid, controller.UpdateFlight("XDLX", "FLO", "AEC134", 10000));
        }


        /// <summary>
        /// This tries to update a flight with an invalid origin
        /// should return a OriginNotValid error
        /// </summary>
        [TestMethod]
        public void InvalidOriginUpdateTest()
        {
            Assert.AreEqual(FlightError.OriginNotValid, controller.UpdateFlight("XD1", "FLOD", "AEC134", 10000));
        }


        /// <summary>
        /// This tries to test the fetch all flights method
        /// </summary>
        [TestMethod]
        public void FlightRetrievalTest()
        {
            //shouldn't have to worry about list being null because our updated list was not deleted
            Assert.AreNotEqual(null, controller.FetchAllFlights()); //this tests that a list of flights is actually being retrieved
        }




    }
}
