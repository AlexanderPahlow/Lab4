﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
	public interface IDatabase
	{
		 FlightError CreateFlight(String origin, String destination, String flightID, int numPax);
		FlightError UpdateFlight(String origin, String destination, String flightID, int numPax);
		List<Flight> FetchAllFlights();
		FlightError DeleteFlight(String flightID);
		bool FlightExists(String flightID);
		void closeDataBase();

	}
}
