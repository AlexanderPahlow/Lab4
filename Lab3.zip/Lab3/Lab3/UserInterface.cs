﻿using System;
using System.Collections.Generic;


// This is left for pedagogy 
// This class is not used in this project

namespace Lab3
{

    public enum MenuOption { CreateFlight, UpdateFlight, DisplayAllFlights, DeleteFlight, ExitProgram}
    public class UserInterface
    {

        Controller controller;

        public UserInterface(Controller controller)
        {
            this.controller = controller;
        }

        
        /// <summary>
        /// Displays the menu and gets user choice
        /// </summary>
        public void DisplayMenu()
        {

            MenuOption menuChoice;

            do
            {
                Console.WriteLine("\nChoose an option: ");
                Console.WriteLine("0. Create a flight");
                Console.WriteLine("1. Update a flight");
                Console.WriteLine("2. Display all flights");
                Console.WriteLine("3. Delete a flight");
                Console.WriteLine("4. Exit program");

                Console.Write("Choice: ");
                menuChoice = (MenuOption)Enum.Parse(typeof(MenuOption), Console.ReadLine());
                Console.WriteLine(menuChoice);
                switch (menuChoice)
                {
                    case MenuOption.CreateFlight: CreateFlight(); break;
                    case MenuOption.UpdateFlight: UpdateFlight(); break;
                    case MenuOption.DisplayAllFlights: DisplayAllFlights(); break;
                    case MenuOption.DeleteFlight: DeleteFlight(); break;
                    case MenuOption.ExitProgram: ExitProgram(); break;
                }

            } while (menuChoice != MenuOption.ExitProgram);
           
        }

        /// <summary>
        /// Creates the flight
        /// </summary>
        public void CreateFlight()
        {
            String origin;
            String destination;
            String flightID;
            int numPax;

            Console.Write("Origin: ");
            origin = Console.ReadLine();
            Console.Write("Destination: ");
            destination = Console.ReadLine();
            Console.Write("Flight ID: ");
            flightID = Console.ReadLine();
            Console.Write("# pax: ");

            bool paxParsingSuccessful = int.TryParse(Console.ReadLine(), out numPax);
            while (!paxParsingSuccessful)
            {
                Console.Write("# pax must be an integer value >= 0");
                Console.Write("# pax: ");
                paxParsingSuccessful = int.TryParse(Console.ReadLine(), out numPax);
            }

            FlightError creationError = controller.CreateFlight(origin, destination, flightID, numPax);
            if (creationError == FlightError.None){
                Console.WriteLine("Flight successfully created");
            } else
            {
                Console.WriteLine("Error in creation: {0}", creationError);
            }

           
        }

        /// <summary>
        /// Updates flight
        /// </summary>
        public void UpdateFlight()
        {
            String origin;
            String destination;
            String flightID;
            int numPax;

            Console.Write("Origin: ");
            origin = Console.ReadLine();
            Console.Write("Destination: ");
            destination = Console.ReadLine();
            Console.Write("Flight ID: ");
            flightID = Console.ReadLine();
            Console.Write("# pax: ");

            bool paxParsingResult;
            do
            {
                paxParsingResult = int.TryParse(Console.ReadLine(), out numPax);

            } while (paxParsingResult == false);

            FlightError updateError = controller.UpdateFlight(origin, destination, flightID, numPax);
            if (updateError == FlightError.None)
            {
                Console.WriteLine("Flight successfully updated");
            }
            else
            {
                Console.WriteLine("Error in updating: {0}", updateError);
            }
        }

        /// <summary>
        /// Displays all flights
        /// </summary>
        public void DisplayAllFlights()
        {
           List<String> flights =  controller.FetchAllFlights();

            Console.WriteLine("\nFlights: ");
            foreach(String flight in flights)
            {
                Console.WriteLine(flight);
            }
        }

        /// <summary>
        /// Deletes all flights
        /// </summary>
        public void DeleteFlight()
        {
            Console.Write("Flight ID: ");
            String flightID = Console.ReadLine();

            FlightError deleteError = controller.DeleteFlight(flightID);
            if (deleteError == FlightError.None)
            {
                Console.WriteLine("Flight successfully deleted");
            } else
            {
                Console.WriteLine("Error in deletion: {0}", deleteError);
            }
        }


        public void ExitProgram()
            {
            System.Environment.Exit(0);
        }

    }
}
