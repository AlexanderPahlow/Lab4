﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;





namespace Lab3
{
    public class Database : IDatabase
    {
        String databaseName = "flights";
        List<Flight> flights; //flight list
        //this is the string we use to connect to the database
        private string connectionStringToDB = ConfigurationManager.ConnectionStrings["MySQLDB"].ConnectionString;
        private MySqlConnection conn;




        /// <summary>
        /// This method makes the data base and intializes the connection string
        /// </summary>
        public Database()
        {
            flights = new List<Flight>();

            //now connnect to the database and open it
            conn = new MySqlConnection(connectionStringToDB);

            if (DatabaseExists())
            {
                ReadFromStorage();
            }
            else
            {
                WriteToStorage();
            }
        }


        /// <summary>
        /// Creates a flight
        /// /// </summary>
        /// <param name="origin"></param> the origin of the flight
        /// <param name="destination"></param> the destination of the flight
        /// <param name="flightID"></param> the flightID
        /// <param name="numPax"></param> the number of passengers on the plane 
        /// <returns>FlightError</returns>
        public FlightError CreateFlight(String origin, String destination, String flightID, int numPax)
        {
            //check for existing flight
            int desiredFlightIndex = flights.FindIndex(tempflight => tempflight.FlightID == flightID); // is there already an existing index?
            if (desiredFlightIndex >= 0)
            {
                return FlightError.DuplicateFlightID;
            }

            FlightError creationError;
            Flight flight = new Flight(origin, destination, flightID, numPax, out creationError);
            if (creationError == FlightError.None)
            {
                //now add the flight
                conn.Open(); //open the database

                //should look like this INSERT INTO `FlightList`(`flightidentifier`, `origin`, `destination`, `numberOfPassengers`) VALUES ("QRS124","FLOR","NZEL",100)
                String toBeInserted = "INSERT INTO `FlightList`(`flightidentifier`, `origin`, `destination`, `numberOfPassengers`) VALUES (\"" + flightID + "\",\"" + origin + "\",\"" + destination + "\"," + numPax + ")";
                //this commands adds a new element to the database
                MySqlCommand cmd = new MySqlCommand(toBeInserted, conn); //this should get all the flights

                //make a reader
                cmd.ExecuteNonQuery(); //excute the command
                conn.Close(); //
                return FlightError.None;
            } else
            {
                return creationError;
            }
        }

        /// <summary>
        /// Updates a flight
        /// </summary>
        /// <param name="origin"></param> the origin of the flight
        /// <param name="destination"></param> the destination of the flight
        /// <param name="flightID"></param> the flightID
        /// <param name="numPax"></param> the number of passengers on the plane 
        /// <returns>FlightError</returns>
        public FlightError UpdateFlight(String origin, String destination, String flightID, int numPax)
        {
            Flight desiredFlight = flights.Find(flight => flight.FlightID == flightID);
            if (desiredFlight == null)
            {
                return FlightError.FlightNotFound;
            }

            if (Flight.OriginValid(origin))
            {
                desiredFlight.Origin = origin;
            }
            else
            {
                return FlightError.OriginNotValid;
            }

            if (Flight.DestinationValid(destination))
            {
                desiredFlight.Destination = destination;
            }
            else
            {
                return FlightError.DestinationNotValid;
            }

            if (Flight.NumPaxValid(numPax))
            {
                desiredFlight.NumPax = numPax;


                //now delete the flight
                //should look like this: DELETE FROM `FlightList` WHERE `flightidentifier` = "ABC123"
                conn.Open(); //open the database

                //should look like this UPDATE `FlightList` SET `origin`="EYOA",`destination`="GAME",`numberOfPassengers`=100 WHERE `flightidentifier` = "ABC123"
                String toBeUpdated = "UPDATE `FlightList` SET `origin`=\"" + origin + "\",`destination`=\"" + destination + "\",`numberOfPassengers`=" + numPax + " WHERE `flightidentifier` = \"" + flightID + "\"";
                //this commands adds a new element to the database
                MySqlCommand cmd = new MySqlCommand(toBeUpdated, conn); //this should get all the flights

                //make a reader
                cmd.ExecuteNonQuery(); //excute the command
                conn.Close(); //
                //WriteToStorage();
                return FlightError.None;
            }
            else
            {
                return FlightError.NumPaxNotValid;
            }
        }

        /// <summary>
        /// Fetches all the flights
        /// </summary>
        /// <returns>FlightError</returns>
        public List<Flight> FetchAllFlights()
        {
            ReadFromStorage();
            return flights;
        }

        /// <summary>
        /// Deletes a flight
        /// </summary>
        /// <param name="flightID"></param> the flightID
        /// <returns>FlightError</returns>
        public FlightError DeleteFlight(String flightID)
        {

            //need to check flightId manually for tests
            //this is mainly for tests file
            if (!CheckFlightIdentifier(flightID))
            {
                return FlightError.FlightIdNotValid; 
            }



            int desiredFlightIndex = flights.FindIndex(flight => flight.FlightID == flightID);
            if (desiredFlightIndex >= 0)
            {
                flights.RemoveAt(desiredFlightIndex);
                //now delete the flight
                //should look like this: DELETE FROM `FlightList` WHERE `flightidentifier` = "ABC123"
                conn.Open(); //open the database

                //should look like this INSERT INTO `FlightList`(`flightidentifier`, `origin`, `destination`, `numberOfPassengers`) VALUES ("QRS124","FLOR","NZEL",100)
                String toBeDeleted = "DELETE FROM `FlightList` WHERE `flightidentifier` = \"" + flightID + "\"";
                //this commands deletes the flight from the database
                MySqlCommand cmd = new MySqlCommand(toBeDeleted, conn); //this should get all the flights

                //make a reader
                cmd.ExecuteNonQuery(); //excute the command
                conn.Close(); 
               //WriteToStorage();
                return FlightError.None;
            }
            return FlightError.FlightNotFound;
        }

        /// <summary>
        /// Determines if flight exists
        /// </summary>
        /// <param name="flightID"></param> the flightID
        /// <returns>true if the flight exists, false otherwise</returns>
        public bool FlightExists(String flightID)
        {
            ReadFromStorage();
            return flights.Find(flight => flight.FlightID == flightID) != null;
        }

        /// <summary>
        /// Returns true if the database exists, false otherwise
        /// </summary>
        /// <returns></returns>
        private bool DatabaseExists()
        {
            return File.Exists(databaseName);
        }


        /// <summary>
        /// Writes to storage
        /// this doesn't actually do anything now because each sql query 
        /// </summary>
        public void WriteToStorage()
        {
            flights.Sort();
            FileStream fileStream = new FileStream(databaseName, FileMode.Create);
            StreamWriter streamWriter = new StreamWriter(fileStream);
            foreach (Flight flight in flights)
            {
                streamWriter.WriteLine(flight);
            }
            streamWriter.Flush();
            streamWriter.Close();
        }

        /// <summary>
        /// This reads every flight from the database and puts them into flights
        /// </summary>
        public void ReadFromStorage()
        {
            flights.Clear();
            
            conn.Open(); //open the database

            MySqlCommand cmd = new MySqlCommand("SELECT * from FlightList", conn); //this should get all the flights

            //make a reader
            MySqlDataReader reader = cmd.ExecuteReader();
            int count = reader.FieldCount;
            while (reader.Read()) //i think this reads in the next line?
            {
                String flightid = (String) reader.GetValue(0);
                Console.WriteLine("hello");
                String origin = (String) reader.GetValue(1);
                String destination = (String)reader.GetValue(2);
                int numOfPass = (int) reader.GetValue(3);
                Flight flightToAdd = new Flight(origin, destination, flightid, numOfPass, out _); //make the new flight
                flights.Add(flightToAdd);
            }

            conn.Close();
            

        }

        /// <summary>
        /// This closes the connection to the database, used for when we are exiting the program
        /// </summary>
        public void closeDataBase()
        {

            conn.Close();
        }



        //CheckFlighIdentifier
        //checks if the flightid answer is valid
        static bool CheckFlightIdentifier(string dest)
        {
            //check if the string is the proper length
            if (dest.Length != 6)
            {
                return false;
            }

            //check that each char of the first 3 is a letter
            for (int i = 0; i < 3; i++)
            {
                if (!Char.IsLetter(dest[i]))
                {
                    return false;

                }
            }

            //check that each char of the last 3 is a number
            for (int i = 3; i < 6; i++)
            {
                if (!Char.IsDigit(dest[i]))
                {
                    return false;
                }
            }


            //if nothing was wrong return true
            return true;

        }

    }
}
