﻿using System;
using System.Collections.Generic;
namespace Lab3
{
    public class Controller : IController
    {
        IDatabase database;

        public Controller(IDatabase database)
        {
            this.database = database;
        }

        /// <summary>
        /// Creates the flight
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="flightID"></param>
        /// <param name="numPax"></param>
        /// <returns>FlightError</returns>
        public FlightError CreateFlight(String origin, String destination, String flightID, int numPax)
        {
            return database.CreateFlight(origin, destination, flightID, numPax);
        }

        /// <summary>
        /// Updates the flight
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="flightID"></param>
        /// <param name="numPax"></param>
        /// <returns>FlightError</returns>
        public FlightError UpdateFlight(String origin, String destination, String flightID, int numPax)
        {
            return database.UpdateFlight(origin, destination, flightID, numPax);
        }

       /// <summary>
       /// Fetches all Flights
       /// </summary>
       /// <returns>a list of flights, as a String</returns>
       public List<String> FetchAllFlights()
        {
            List<Flight> flights = database.FetchAllFlights();
            List<String> flightsRepresentation = new List<String>();
            foreach (Flight flight in flights) {
                flightsRepresentation.Add(flight.ToString());
            }

            return flightsRepresentation;
        }

        /// <summary>
        /// Deletes a flight
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns>FlightError</returns>
        public FlightError DeleteFlight(String flightID)
        {
            return database.DeleteFlight(flightID);
        }

        /// <summary>
        /// Determines if the flight exists
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns>FlightError</returns>
        public bool FlightExists(String flightID)
        {
            return database.FlightExists(flightID);
        }

        /// <summary>
        /// Exits the program
        /// </summary>
        public void ExitProgram()
        {
            database.closeDataBase();
            System.Windows.Application.Current.Shutdown(); //turn off the application
        }
    }
}
