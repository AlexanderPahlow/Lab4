﻿using System;
using System.Collections.Generic;
//using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for CreateFlightWindow.xaml
    /// </summary>
    public partial class CreateFlightWindow : Window
    {
        MainWindow mainWindow;
        /// <summary>
        /// Constructor - sets mainWindow so we can talk back to the rest of the UI
        /// </summary>
        /// <param name="mainWindow"></param>
        public CreateFlightWindow(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mainWindow = mainWindow;

        }

        /// <summary>
        /// Called when user clicks Create
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Create(object sender, RoutedEventArgs e)
        {
            String flightID = flightIDTB.Text;
            String origin = originTB.Text;
            String destination = destinationTB.Text;
            int numPax;

            var parsingSuccessful = int.TryParse(numPaxTB.Text, out numPax);
            if (!parsingSuccessful || numPax < 0)
            {
                MessageBox.Show(this, "# pax must be a non-negative integer value", "Error in Passenger Count");
            }
            else
            {
                mainWindow.CreateFlight(origin, destination, flightID, numPax);
                this.Close();
            }
        }

        /// <summary>
        /// Called when user clicks Cancel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


    }

}
