﻿using System;
using System.Collections.Generic;
//using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for CreateFlightWindow.xaml
    /// </summary>
    public partial class UpdateFlightWindow : Window
    {
        MainWindow mainWindow;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mainWindow"></param>
        public UpdateFlightWindow(MainWindow mainWindow)
        {
            InitializeComponent();
            this.mainWindow = mainWindow;
        }

        /// <summary>
        /// Calls when the user clicks on Update button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Update(object sender, RoutedEventArgs e)
        {
            String flightID = flightIDTB.Text;
            String origin = originTB.Text;
            String destination = destinationTB.Text;
            int numPax;

            var parsingSuccessful = int.TryParse(numPaxTB.Text, out numPax);
            if (!parsingSuccessful || numPax < 0)
            {
                MessageBox.Show(this, "# pax must be a non-negative integer value", "Error in passenger count");
            }
            else
            {
                mainWindow.UpdateFlight(origin, destination, flightID, numPax);
                this.Close();
            }
        }

        /// <summary>
        /// Calls when the user clicks on Cancel button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

    }
}

