﻿using System;
namespace Lab3
{
    public enum FlightError { None, OriginNotValid, DestinationNotValid, FlightIdNotValid, NumPaxNotValid, DuplicateFlightID, FlightNotFound };
    public class Flight : IEquatable<Flight>, IComparable<Flight>
    {
        public enum FlightFieldLocation { Origin, Destination, FlightID, NumPax };
        
        //constants for checking the length of flights attributes
        const int REQUIRED_ORIGIN_LENGTH = 4;
        const int REQUIREDL_DESTINATION_LENGTH = 4;
        const int REQUIRED_FLIGHT_ID_LENGTH = 6;
        const int FLIGHT_ID_NUMBER_STARTING_INDEX = 3;


        //constructors for all the local vars

        public String FlightID { get; set; }
        public String Origin { get; set; }
        public String Destination { get; set; }
        public int NumPax { get; set; }

        /// <summary>
        /// Makes a flight
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="flightID"></param>
        /// <param name="numPax"></param>
        public Flight(String origin, String destination, String flightID, int numPax, out FlightError error)
        {

            if (!OriginValid(origin))
            {
                error = FlightError.OriginNotValid;
            }
            else if (!DestinationValid(destination))
            {
                error = FlightError.DestinationNotValid;
            }
            else if (!FlightIDValid(flightID))
            {
                error = FlightError.FlightIdNotValid;
            }
            else if (!NumPaxValid(numPax))
            {
                error = FlightError.NumPaxNotValid;
            }
            else
            {
                error = FlightError.None;

                this.Origin = origin;
                this.Destination = destination;
                this.FlightID = flightID;
                this.NumPax = numPax;
            }
        }

        /// <summary>
        /// Returns true if origin is valid
        /// </summary>
        /// <param name="origin"></param>
        /// <returns>whether origin is valid</returns>
        public static bool OriginValid(String origin)
        {
            if (origin.Length != REQUIRED_ORIGIN_LENGTH)
            {
                return false;
            }

            //check that each char in the string is a letter
            for (int i = 0; i < origin.Length; i++)
            {
                if (!Char.IsLetter(origin[i]))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Retruns true if destination is valid
        /// </summary>
        /// <param name="destination"></param>
        /// <returns>whether destination is valid</returns>
        public static bool DestinationValid(String destination)
        {
            if (destination.Length != REQUIREDL_DESTINATION_LENGTH)
            {
                return false;
            }

            //check that each char in the string is a letter
            for (int i = 0; i < destination.Length; i++)
            {
                if (!Char.IsLetter(destination[i]))
                {
                    return false;
                }
            }

            return true;

        }

        /// <summary>
        /// Returns true if flight ID is valid
        /// </summary>
        /// <param name="flightID"></param>
        /// <returns>whether flight ID is valide></returns>
        public static bool FlightIDValid(String flightID)
        {
            String letterHalf = flightID.Substring(0, FLIGHT_ID_NUMBER_STARTING_INDEX);
            String numberHalf = flightID.Substring(FLIGHT_ID_NUMBER_STARTING_INDEX);

            bool numberFound = int.TryParse(numberHalf, out _);
            return flightID.Length == REQUIRED_FLIGHT_ID_LENGTH && numberFound;
        }

        /// <summary>
        /// Returns true if # of pax is valid
        /// </summary>
        /// <param name="numPax"></param>
        /// <returns>whether # pax is valid</returns>
        public static bool NumPaxValid(int numPax)
        {
            return numPax >= 0;
        }

        /// <summary>
        /// Returns true if two flights are equal
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        bool IEquatable<Flight>.Equals(Flight other)
        {
            return FlightID == other.FlightID;
        }

        /// <summary>
        /// Returns a String representation of a flight
        /// </summary>
        /// <returns>a comma delimited representation</returns>
        public override string ToString()
        {
            return String.Format("{0},{1},{2},{3}", Origin, Destination, FlightID, NumPax);
        }

        /// <summary>
        /// Compares two flights - used for sorting flights by flight ID
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        int IComparable<Flight>.CompareTo(Flight other)
        {
            return FlightID.CompareTo(other.FlightID);
        }
    }
}
