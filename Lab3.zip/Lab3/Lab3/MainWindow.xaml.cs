﻿// https://github.com/fsprojects/Fabulous/issues/307

// System.Diagnostics.Debug.WriteLine() -- really?? really.

using Lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Lab3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public IController controller;

        /// <summary>
        /// Constructor - essentially the "Main" of this app
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            IDatabase database = new Database();
            controller = new Controller(database);
            System.Diagnostics.Debug.WriteLine("database made");
            RefreshFlightsTB();
            // Remnants of Lab1
            // UserInterface userInterface = new UserInterface(controller: controller);
            // userInterface.DisplayMenu();


        }

        /// <summary>
        /// Called when user clicks Create Flight button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CreateFlight_Click(object sender, RoutedEventArgs e)
        {
            CreateFlightWindow createFlightWindow = new CreateFlightWindow(this);
            createFlightWindow.Show();
        }

        /// <summary>
        /// Callback when user clicks on Create button in the CreateFlightWindow
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="flightID"></param>
        /// <param name="numPax"></param>
        public void CreateFlight(String origin, String destination, String flightID, int numPax)
        {
            FlightError error = controller.CreateFlight(origin, destination, flightID, numPax);
            if (error == FlightError.None) {
                RefreshFlightsTB();
            } else
            {
                MessageBox.Show(this, "Error: " + error, "Error Creating Flight");
            }
        }

        
        /// <summary>
        /// Redraws the flightsLB to reflect the current state of the database
        /// </summary>
        private void RefreshFlightsTB()
        {
            flightsLB.Items.Clear();
            List<String> flights = controller.FetchAllFlights();
            foreach (String flight in flights)
            {
                flightsLB.Items.Add(PrettifyFlight(flight));
            }
        }

        /// <summary>
        /// Called when the user clicks Update Flight button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateFlight_Click(object sender, RoutedEventArgs e)
        {
            UpdateFlightWindow updateFlightWindow = new UpdateFlightWindow(this);
            updateFlightWindow.Show();
        }

        /// <summary>
        /// Callback when the user clicks Update from the UpdateFlightWindow
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="destination"></param>
        /// <param name="flightID"></param>
        /// <param name="numPax"></param>
        public void UpdateFlight(String origin, String destination, String flightID, int numPax)
        {
            FlightError error = controller.UpdateFlight(origin, destination, flightID, numPax);
            if (error == FlightError.None)
            {
                RefreshFlightsTB();
            }
            else
            {
                MessageBox.Show(this, "Error: " + error, "Error Updating Flight");
            }
        }

         /// <summary>
        /// Calls when the user clicks Delete Flight button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteFlight_Click(object sender, RoutedEventArgs e)
        {
            if(flightsLB.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select a flight before clicking Delete Flight", "Attention");
                return;
            }
            String flightIDToDelete = flightsLB.SelectedItem.ToString().Split(':')[0];
            controller.DeleteFlight(flightIDToDelete);
            RefreshFlightsTB();

        }

        /// <summary>
        /// Called when the user clicks Exit Program button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExitProgram_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
            controller.ExitProgram();
        }

        /// <summary>
        /// Prettifies the String so we can display it
        /// </summary>
        /// <param name="flight"></param>
        /// <returns></returns>
        private String PrettifyFlight(String flight)
        {
            String[] parts = flight.Split(',');
            return String.Format("{0}: {1} -> {2} ({3})", parts[(int)Flight.FlightFieldLocation.FlightID],
                parts[(int)Flight.FlightFieldLocation.Origin],
                parts[(int)Flight.FlightFieldLocation.Destination],
                parts[(int)Flight.FlightFieldLocation.NumPax]);
        }



    }
}
