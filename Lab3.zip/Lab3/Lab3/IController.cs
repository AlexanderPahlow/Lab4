﻿using System;
using System.Collections.Generic;
using System.Text;
using  Lab3;

namespace Lab3
{
    public interface IController
    {
		 FlightError CreateFlight(String origin, String destination, String flightID, int numPax);
		 FlightError UpdateFlight(String origin, String destination, String flightID, int numPax);
		 List<String> FetchAllFlights();
		 FlightError DeleteFlight(String flightID);
		 bool FlightExists(String flightID);
		 void ExitProgram();
	}
}
